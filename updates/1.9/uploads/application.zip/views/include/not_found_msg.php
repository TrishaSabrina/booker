<div class="text-center mb-5 mb-md-7 mb-lg-9 mt-5">
    <div class="d-flex justify-content-center align-items-center">
        <div class="pt-10 pb-10">
            <h2 class="text-muted mt-6"><i class="lni lni-empty-file text-primary"></i></h2>
            <p class="text-muted"><span><?php echo trans('no-data-found') ?></span></p>
        </div>
    </div>
</div>