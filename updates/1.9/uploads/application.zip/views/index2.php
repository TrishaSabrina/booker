<?php include'include/header2.php';?>
  <?php echo $main_content;?>
<?php include'include/footer2.php';?>
