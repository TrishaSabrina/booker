<div class="empty-data text-center">
  <h2 class="text-muted"><i class="lni lni-empty-file"></i></h2>
  <p><?php echo trans('no-data-found') ?></p>
</div>